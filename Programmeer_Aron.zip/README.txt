Het spel oorlog is simulatie van de game War, zie hieronder voor meer informatie.
https://en.wikipedia.org/wiki/War_(card_game)

Met het bieravontuur ga je op zoek naar het perfecte biertje in de stad groningen.

De rest spreekt voor zichzelf.
